# -*- coding: utf-8 -*-

import random
import sys
from prime_num import generate_prime, AlgEvklid


def factorize(n):
    fact = []
    i = 2
    while (i*i <= n):
        if n % i == 0:
            fact.append(i)
            while n % i == 0:
                n /= i
        i += 1

    if n > 1:
        fact.append(n)

def main():
    file = open(sys.argv[1], 'rb').read()
    fout = open(sys.argv[2], 'w')
    for i in file:
        num = ord(i)
        bits = []
        print num
        while num / 2 != 0:
            modulo = num % 2
            if modulo == 1:
                bits.append(True)
            else:
                bits.append(False)
            num /= 2
        if num != 0:
            if num == 1:
                bits.append(True)
            else:
                bits.append(False)
        while len(bits) < 8:
            bits.append(False)
        print bits
        for bit in bits:
            if bit:
                num1 = None
                while num1 is None:
                    num1 = generate_prime(271345838280909634783840377047987070130610929692119657962127, 100)
                #print num1
                fout.write(str(num1))
            else:
                num1 = None
                num2 = None
                while num1 is None:
                    num1 = generate_prime(271345838280909634783840377047987070130610929692119657962127, 100)
                #print num1
                while num2 is None:
                    num2 = generate_prime(17, 100)
                #print num2
                fout.write(str(num1*num2))
            fout.write("\n")
    return

if __name__ == "__main__":
    main()
